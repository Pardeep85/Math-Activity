1. Open your terminal and run the following command to install the necessary packages: npm install

2. Once the installation is complete, start the application by running: node index.js

3. Open your web browser and go to http://localhost:4000 to play the game